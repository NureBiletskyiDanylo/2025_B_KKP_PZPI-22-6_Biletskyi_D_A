export interface ViolationModel {
    id: number;
    violationText: string;
    violatedAt: Date;
}