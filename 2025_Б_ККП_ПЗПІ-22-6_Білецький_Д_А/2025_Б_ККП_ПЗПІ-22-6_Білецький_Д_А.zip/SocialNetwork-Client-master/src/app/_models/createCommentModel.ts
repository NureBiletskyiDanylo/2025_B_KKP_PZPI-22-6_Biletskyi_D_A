export interface CreateCommentModel {
    content: string;
    publicationId: number;
}