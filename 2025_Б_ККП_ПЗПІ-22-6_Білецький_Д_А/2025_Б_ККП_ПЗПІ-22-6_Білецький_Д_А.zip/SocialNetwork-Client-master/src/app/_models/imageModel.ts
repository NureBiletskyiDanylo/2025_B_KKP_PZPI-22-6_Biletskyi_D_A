export interface ImageModel{
    int: number;
    publicId: string;
    imageUrl: string;
}