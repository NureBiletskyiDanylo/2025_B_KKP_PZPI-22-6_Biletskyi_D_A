export interface AccountModel {
    username: string,
    uniqueNameIdentifier: string,
    token: string,
    role: string,
    blocked: boolean,
}