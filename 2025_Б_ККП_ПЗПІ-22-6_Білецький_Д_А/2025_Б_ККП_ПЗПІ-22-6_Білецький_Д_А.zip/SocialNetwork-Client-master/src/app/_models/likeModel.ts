export interface LikeModel{
    amountOfLikes: number;
    isLikedByCurrentUser: boolean;
}