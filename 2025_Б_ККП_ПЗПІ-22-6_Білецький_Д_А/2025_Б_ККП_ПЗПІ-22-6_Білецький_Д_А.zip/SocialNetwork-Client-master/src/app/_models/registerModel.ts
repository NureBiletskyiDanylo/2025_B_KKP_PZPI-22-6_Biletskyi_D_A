export interface RegisterModel {
    username: string,
    email: string,
    password: string,
    image?: File
}