export interface CreateViolationModel {
    itemToRemoveId: number;
    removalReason: string;
    violationScoreIncrease: number;
}