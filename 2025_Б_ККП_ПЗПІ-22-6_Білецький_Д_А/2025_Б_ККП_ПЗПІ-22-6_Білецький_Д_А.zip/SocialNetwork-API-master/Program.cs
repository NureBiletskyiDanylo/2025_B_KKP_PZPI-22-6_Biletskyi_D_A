using Microsoft.AspNetCore.Diagnostics;
using Microsoft.EntityFrameworkCore;
using Microsoft.OpenApi.Models;
using Neo4j.Driver;
using Serilog;
using Serilog.Events;
using SocialNetworkAPI.Data;
using SocialNetworkAPI.Extensions;
using SocialNetworkAPI.Interfaces;
using SocialNetworkAPI.Neo4j;
using SocialNetworkAPI.Services;

var builder = WebApplication.CreateBuilder(args);

Directory.CreateDirectory("Log");

Log.Logger = new LoggerConfiguration()
    .MinimumLevel.Debug()
    .MinimumLevel.Override("Microsoft", LogEventLevel.Debug)
    .MinimumLevel.Override("System", LogEventLevel.Debug)
    .Enrich.FromLogContext()
    .WriteTo.Console(outputTemplate: "[{Timestamp:HH:mm:ss} {Level:u3}] {Message:lj}{NewLine}{Exception}")
    //.WriteTo.File("Log/error-logs.json", rollingInterval: RollingInterval.Year)
    .CreateLogger();


builder.Host.UseSerilog(Log.Logger);

builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(c =>
{
    c.SwaggerDoc("v1", new OpenApiInfo { Title = "SocialNetworkAPI", Version = "v1" });

    // Add the JWT security scheme
    c.AddSecurityDefinition("Bearer", new OpenApiSecurityScheme
    {
        Description = "JWT Authorization header using the Bearer scheme. Example: 'Bearer {token}'",
        Name = "Authorization",
        In = ParameterLocation.Header,
        Type = SecuritySchemeType.Http,
        Scheme = "bearer",
        BearerFormat = "JWT"
    });

    // Add global security requirement
    c.AddSecurityRequirement(new OpenApiSecurityRequirement
    {
        {
            new OpenApiSecurityScheme
            {
                Reference = new OpenApiReference
                {
                    Type = ReferenceType.SecurityScheme,
                    Id = "Bearer"
                },
                Scheme = "oauth2", // Doesn't really matter here; just needed
                Name = "Bearer",
                In = ParameterLocation.Header
            },
            Array.Empty<string>()
        }
    });
});


builder.Services.AddControllers();

// PostgreSQL Connection
builder.Services.AddDbContext<DataContext>(options =>
{
    options.UseNpgsql(builder.Configuration.GetConnectionString("DefaultPGConnection"));
});

//Neo4j Connection
var settings = new Neo4jSettings();
builder.Configuration.GetSection("Neo4jSettings").Bind(settings);
try
{
    var neo4jDriver = GraphDatabase.Driver(
        settings.Neo4jConnection,
        AuthTokens.Basic(settings.Neo4juser, settings.Neo4jPassword)
    );
    builder.Services.AddSingleton(neo4jDriver);
    builder.Services.AddSingleton<INeo4jDataAccess, Neo4jDataAccess>();
    builder.Services.AddScoped<ISubscriptionService, SubscriptionService>();
}
catch (Exception ex)
{
    Log.Fatal(ex, "Failed to initialize Neo4j Driver");
    throw;
}

builder.Services.AddApplicationServices(builder.Configuration);

// Build the app
var app = builder.Build();


// SWAGGER
app.UseSwagger();
app.UseStaticFiles();

app.UseSwaggerUI(c =>
{
    c.SwaggerEndpoint("/swagger/v1/swagger.json", "SocialNetworkAPI V1");
});

app.UseCors(x =>
{
    x.AllowAnyHeader();
    x.AllowAnyMethod();
    x.AllowAnyOrigin();
});

app.UseHttpsRedirection();

app.UseAuthentication();
app.UseAuthorization();
app.UseExceptionHandler(errApp =>
{
    errApp.Run(async context =>
    {
        var exceptionHandler = context.Features.Get<IExceptionHandlerFeature>();
        if (exceptionHandler != null)
        {
            var logger = context.RequestServices.GetRequiredService<ILogger<Program>>();
            logger.LogError(exceptionHandler.Error, "Unhandled exception");
        }
        await context.Response.WriteAsync("An unexpected error occurred.");
    });
});
app.MapControllers();

try
{
app.Run();
}
catch (Exception ex)
{
    Log.Fatal(ex, "Application terminated unexpectedly");
}
finally
{
    Log.Information("Shutting down application");
    Log.CloseAndFlush();
}

AppDomain.CurrentDomain.ProcessExit += (_, __) =>
{
    Log.Information("ProcessExit event triggered - application is shutting down.");
    Log.CloseAndFlush();  // Make sure logs flush to file
};

