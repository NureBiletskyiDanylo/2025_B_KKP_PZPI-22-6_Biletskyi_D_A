﻿namespace SocialNetworkAPI.Enums;

public enum Roles
{
    User,
    Admin
}
