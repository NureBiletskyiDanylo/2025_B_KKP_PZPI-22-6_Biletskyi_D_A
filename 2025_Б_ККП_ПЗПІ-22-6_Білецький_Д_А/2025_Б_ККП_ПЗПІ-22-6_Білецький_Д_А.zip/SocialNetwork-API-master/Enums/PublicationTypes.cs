﻿namespace SocialNetworkAPI.Enums;

public enum PublicationTypes
{
    ordinary,
    planned
}
