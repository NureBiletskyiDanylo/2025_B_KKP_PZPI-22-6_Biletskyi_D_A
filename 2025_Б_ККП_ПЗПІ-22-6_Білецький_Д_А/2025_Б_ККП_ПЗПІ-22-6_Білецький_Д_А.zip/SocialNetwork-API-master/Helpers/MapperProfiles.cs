﻿namespace SocialNetworkAPI.Helpers;
using AutoMapper;
using SocialNetworkAPI.Data.Entities;
using SocialNetworkAPI.DTOs;
using SocialNetworkAPI.DTOs.AdminDTOs;

public class MapperProfiles : Profile
{
    public MapperProfiles()
    {
        CreateMap<LoginDto, User>();
        CreateMap<User, MemberDto>()
            .ForMember(u => u.JoinedAt, opt => opt.MapFrom(u => u.DateOfCreation.ToString()));

        CreateMap<CreatePublicationDto, Publication>()
            .ForMember(a => a.Images, opt => opt.Ignore());
        CreateMap<Image, ImageDto>();
        CreateMap<Publication, PublicationDto>()
            .ForMember(a => a.LikesAmount, src => src.MapFrom(a => a.Likes.Count))
            .ForMember(a => a.CommentAmount, src => src.MapFrom(a => a.Comments.Count))
            .ForMember(a => a.IsLikedByCurrentUser, opt => opt.Ignore());
        CreateMap<UpdateMemberDto, User>()
            .ForMember(a => a.ProfileImage, opt => opt.Ignore());

        CreateMap<User, UserDto>()
            .ForMember(a => a.AmountOfViolations, src => src.MapFrom(a => a.Violations.Count));

        CreateMap<Violation, ViolationDto>();


        CreateMap<Comment, CommentDto>();

    }
}
