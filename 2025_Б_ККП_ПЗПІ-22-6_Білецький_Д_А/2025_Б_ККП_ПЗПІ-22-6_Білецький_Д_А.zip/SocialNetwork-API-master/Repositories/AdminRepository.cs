﻿namespace SocialNetworkAPI.Repositories;

using AutoMapper;
using Microsoft.EntityFrameworkCore;
using SocialNetworkAPI.Data;
using SocialNetworkAPI.Data.Entities;
using SocialNetworkAPI.DTOs.AdminDTOs;
using SocialNetworkAPI.Exceptions;
using SocialNetworkAPI.Interfaces;
using System.Threading.Tasks;

public class AdminRepository(DataContext context, IMapper mapper, IEmailService emailService) : IAdminRepository
{
    const int VIOLATION_LIMIT = 20;

    public async Task<bool> DeleteComment(CreateViolationDto violationModel)
    {
        using var transaction = await context.Database.BeginTransactionAsync();
        try
        {
            Comment? comment = await context.Comments.Include(a => a.Author).FirstOrDefaultAsync(a => a.Id == violationModel.ItemToRemoveId);
            if (comment == null || comment.Author == null) return false;
            string email = comment.Author.Email;
            context.Comments.Remove(comment);

            
            Violation violation = new Violation
            {
                ViolationText = violationModel.RemovalReason,
                ViolatedAt = DateTime.UtcNow,
                ViolatedBy = comment.Author,
                ViolatedById = comment.Author.Id
            };


            bool result = await RegisterViolation(violation, comment.Author, violationModel.ViolationScoreIncrease);

            await transaction.CommitAsync();
            await SendCommentPublicationEmail(false, email, violation);

            return result;
        }
        catch
        {
            await transaction.RollbackAsync();
            return false;
        }

    }

    public async Task<bool> DeletePublication(CreateViolationDto violationModel)
    {
        using var transaction = await context.Database.BeginTransactionAsync();

        try
        {
            var publication = await context.Publications
                .Include(a => a.Author)
                .FirstOrDefaultAsync(a => a.Id == violationModel.ItemToRemoveId);

            if (publication == null || publication.Author == null) return false;
            string email = publication.Author.Email;
            
            context.Publications.Remove(publication);

            var violation = new Violation
            {
                ViolationText = violationModel.RemovalReason,
                ViolatedAt = DateTime.UtcNow,
                ViolatedBy = publication.Author,
                ViolatedById = publication.Author.Id
            };

            bool result = await RegisterViolation(violation, publication.Author,
                               violationModel.ViolationScoreIncrease);

            await transaction.CommitAsync();
            await SendCommentPublicationEmail(true, email, violation);
            return result;
        }
        catch
        {
            await transaction.RollbackAsync();
            throw;
        }
    }

    public async Task<bool> UnblockUser(int userId)
    {
        User? user = await context.Users.FindAsync(userId);
        if (user == null) return false;
        user.Blocked = false;
        user.BlockedAt = null;
        user.ViolationScore = 0;
        context.Users.Update(user);

        await SendUnblockedNotificationEmail(user.Email);

        return await context.SaveChangesAsync() > 0;
    }
    public async Task<bool> BlockUser(int userId)
    {
        User? user = await context.Users.FindAsync(userId);
        if (user == null) return false;
        user.Blocked = true;
        user.BlockedAt = DateTime.UtcNow;
        context.Users.Update(user);

        await SendBlockedNotificationEmail(user.Email);

        return await context.SaveChangesAsync() > 0;
    }

    public async Task<List<UserDto>> GetUsers()
    {
        List<User> users = await context.Users.Include(a => a.ProfileImage).Include(a => a.Violations).ToListAsync();

        List<UserDto> userModels = mapper.Map<List<UserDto>>(users);

        return userModels;
    }

    public async Task<List<ViolationDto>> GetViolationByUserIdAsync(int userId)
    {
        bool userExists = await context.Users.AnyAsync(a => a.Id == userId);
        if (!userExists) throw new NotFoundException("User was not found");
        List<Violation> violations = await context.Violations.Where(a => a.ViolatedById == userId).ToListAsync();

        List<ViolationDto> violationModels = mapper.Map<List<ViolationDto>>(violations);
        return violationModels;
    }

    private async Task<bool> RegisterViolation(Violation violation, User user, int violationScoreIncrease)
    {
        await context.Violations.AddAsync(violation);
        user.ViolationScore += violationScoreIncrease;
        if (user.ViolationScore >= VIOLATION_LIMIT)
        {
            user.Blocked = true;
            user.BlockedAt = DateTime.UtcNow;
        }
        context.Users.Update(user);

        return await context.SaveChangesAsync() > 0;
    }

    private async Task SendCommentPublicationEmail(bool isPublication, string email, Violation violation)
    {
        string item = isPublication ? "publication" : "comment";
        string message = $@"<!DOCTYPE html>
<html>
<head>
    <style>
        body {{ font-family: Arial, sans-serif; color: #333; }}
        .container {{ padding: 20px; border: 1px solid #ddd; border-radius: 8px; }}
        .reason {{ background-color: #f9f9f9; padding: 10px; border-left: 4px solid #e74c3c; margin-top: 10px; }}
    </style>
</head>
<body>
    <div class=""container"">
        <h2>Notice of Content Removal</h2>
        <p>Dear user,</p>
        <p>Your recent <strong> {item}</strong> has been removed due to a violation of our community guidelines.</p>
        <p><strong>Reason:</strong></p>
        <div class=""reason"">
            {violation.ViolationText}
        </div>
        <p>Your violation score has been increased. Continued violations may result in account restrictions.</p>
        <p>Thank you for your understanding.</p>
        <p>The Moderation Team</p>
    </div>
</body>
</html>";

        await emailService.SendEmailAsync(email, $"Your {item} was deleted", message);
    }

    private async Task SendBlockedNotificationEmail(string email)
    {
        string message = $@"<!DOCTYPE html>
<html>
<head>
    <style>
        body {{ font-family: Arial, sans-serif; color: #333; }}
        .container {{ padding: 20px; border: 1px solid #ddd; border-radius: 8px; }}
    </style>
</head>
<body>
    <div class=""container"">
        <h2>Your Account Has Been Blocked</h2>
        <p>Dear user,</p>
        <p>Due to multiple violations of our terms of service, your account has been temporarily <strong>blocked</strong>.</p>
        <p>If you believe this was a mistake or wish to appeal, please contact our support team.</p>
        <p>Regards,<br>The Moderation Team</p>
    </div>
</body>
</html>
";

        await emailService.SendEmailAsync(email, $"Your account was blocked", message);
    }

    private async Task SendUnblockedNotificationEmail(string email)
    {
        string message = $@"<!DOCTYPE html>
<html>
<head>
    <style>
        body {{ font-family: Arial, sans-serif; color: #333; }}
        .container {{ padding: 20px; border: 1px solid #ddd; border-radius: 8px; }}
    </style>
</head>
<body>
    <div class=""container"">
        <h2>Account Unblocked</h2>
        <p>Dear user,</p>
        <p>We’re writing to inform you that your account has been successfully <strong>unblocked</strong>. You may now log in and continue using our platform.</p>
        <p>We encourage you to follow our community guidelines to avoid future restrictions.</p>
        <p>Best regards,<br>The Moderation Team</p>
    </div>
</body>
</html>

";

        await emailService.SendEmailAsync(email, $"Your account was unblocked", message);
    }
}
