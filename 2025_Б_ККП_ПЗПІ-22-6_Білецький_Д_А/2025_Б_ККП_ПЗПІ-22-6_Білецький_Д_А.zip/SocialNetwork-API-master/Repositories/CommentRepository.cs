﻿namespace SocialNetworkAPI.Repositories;

using AutoMapper;
using Microsoft.EntityFrameworkCore;
using SocialNetworkAPI.Data;
using SocialNetworkAPI.Data.Entities;
using SocialNetworkAPI.DTOs;
using SocialNetworkAPI.Exceptions;
using SocialNetworkAPI.Interfaces;
using System.Collections.Generic;
using System.Threading.Tasks;

public class CommentRepository(DataContext context, IMapper mapper) : ICommentRepository
{
    public async Task<CommentDto> CreateCommentAsync(CreateCommentDto model, int userId)
    {
        var user = await context.Users.Include(a => a.ProfileImage).FirstOrDefaultAsync(a => a.Id == userId);
        if (user == null) throw new NotFoundException("User does not exist");

        var publication = await context.Publications.FindAsync(model.PublicationId);
        if (publication == null) throw new NotFoundException("Publication does not exist");

        Comment comment = new Comment
        {
            Author = user,
            Publication = publication,
            Content = model.Content,
            CreationDate = DateTime.UtcNow
        };

        context.Comments.Add(comment);

        bool result = await context.SaveChangesAsync() > 0;
        if (result)
        {
            var newComment = mapper.Map<CommentDto>(comment);
            return newComment;
        }
        throw new DbUpdateException("Comment was not saved");
    }

    public async Task<bool> DeleteCommentAsync(int id)
    {
        var comment = await context.Comments.FindAsync(id);
        if (comment == null) return false;

        context.Comments.Remove(comment);
        return await context.SaveChangesAsync() > 0;
    }

    public async Task<List<CommentDto>> GetCommentsByPostId(int postId)
    {
        var comments = await context.Comments.Include(a => a.Author).ThenInclude(a => a.ProfileImage).Where(a => a.PublicationId == postId).ToListAsync();

        if (comments == null) return new List<CommentDto>();

        List<CommentDto> commentsModel = mapper.Map<List<CommentDto>>(comments);
        return commentsModel;
    }
}
