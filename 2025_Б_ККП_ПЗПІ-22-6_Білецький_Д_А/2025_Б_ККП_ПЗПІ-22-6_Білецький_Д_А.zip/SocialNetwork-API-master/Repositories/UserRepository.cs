﻿using AutoMapper;
using AutoMapper.QueryableExtensions;
using Microsoft.EntityFrameworkCore;
using SocialNetworkAPI.Data;
using SocialNetworkAPI.Data.Entities;
using SocialNetworkAPI.DTOs;
using SocialNetworkAPI.Exceptions;
using SocialNetworkAPI.Interfaces;
using System.Collections.Immutable;

namespace SocialNetworkAPI.Repositories;

public class UserRepository(DataContext context, IMapper mapper,
    IPhotoService photoService) : IUserRepository
{
    public async Task<bool> CheckForUserExistenceByEmailAsync(string email)
    {
        bool exists = await context.Users.AnyAsync(u => u.Email == email);
        return exists;
    }

    public async Task<bool> CheckIfUniqueNameIdentifierTaken(string nameIdentifier)
    {
        bool exists = await context.Users.AnyAsync(u => u.UniqueNameIdentifier == nameIdentifier);
        return exists;
    }

    public async Task<bool> CreateUserAccountAsync(User user)
    {
        using var transaction = await context.Database.BeginTransactionAsync();
        try
        {
            if (user.ProfileImage != null)
            {
                await context.Images.AddAsync(user.ProfileImage);
                await context.SaveChangesAsync();
            }

            await context.Users.AddAsync(user);
            var result = await context.SaveChangesAsync() > 0;

            await transaction.CommitAsync();
            return result;
        }
        catch
        {
            await transaction.RollbackAsync();
            throw new DbUpdateException("It was impossible to store user in the database");
        }
    }

    public async Task<MemberDto?> GetUserAccountByIdAsync(int userId)
    {
        User? user = await context.Users.Include(a => a.ProfileImage).FirstOrDefaultAsync(a => a.Id == userId);
        if (user == null) throw new NotFoundException("User was not found");
        var mappedUser = mapper.Map<MemberDto>(user);
        return mappedUser;
    }

    public async Task<MemberDto?> GetUserByEmailAsync(string email)
    {
        var user = await context.Users.Include(a => a.ProfileImage).FirstOrDefaultAsync(u => u.Email == email);
        var mappedUser = mapper.Map<MemberDto>(user);
        return mappedUser;
    }

    public async Task<bool> RemoveUserAccountAsync(User user)
    {
        context.Users.Remove(user);
        return await context.SaveChangesAsync() > 0;
    }

    public async Task<bool> RemoveUserAccountByIdAsync(int userId)
    {
        User? user = await context.Users.Include(a => a.ProfileImage).FirstOrDefaultAsync(a => a.Id == userId);
        if (user == null)
            return false;
        
        if (user.ProfileImage != null)
        {
            var deletionResponse = await photoService.DeletePhotoAsync(user.ProfileImage.PublicId!);
            if (deletionResponse.Error != null) throw new ImageStoreException("Image was not deleted");
        }

        context.Users.Remove(user);
        return await context.SaveChangesAsync() > 0;
    }

    public async Task<MemberDto?> UpdateUserAccountAsync(User updatedUser)
    {
        using var transaction = await context.Database.BeginTransactionAsync();
        var existingUser = await context.Users.Include(a => a.ProfileImage)
            .FirstOrDefaultAsync(a => a.Id == updatedUser.Id);

        if (existingUser == null)
        {
            throw new NotFoundException("User was not found");
        }

        existingUser.Username = updatedUser.Username;
        existingUser.UniqueNameIdentifier = updatedUser.UniqueNameIdentifier;

        await HandleProfileImageUpdate(existingUser, updatedUser);
        context.Users.Update(existingUser);
        bool result = await context.SaveChangesAsync() > 0;
        if (result)
        {
            await transaction.CommitAsync();
            return mapper.Map<MemberDto>(existingUser);
        }
        await transaction.RollbackAsync();
        throw new DbUpdateException("Unfortunately the user was not updated");
    }

    private async Task HandleProfileImageUpdate (User existingUser, User updatedUser)
    {
        // Case 1 - User didn't have photo and doesn't need any (шо тут поделать, ничего)

        // Case 2 - User didn't have photo, now he wants one 

        if (existingUser.ProfileImage == null && updatedUser.ProfileImage != null)
        {
            await context.Images.AddAsync(updatedUser.ProfileImage);
            existingUser.ProfileImage = updatedUser.ProfileImage;
        }

        // Case 3 - User had photo, now he wants to get rid of it

        else if (existingUser.ProfileImage != null && updatedUser.ProfileImage == null)
        {
            var imageToRemove = existingUser.ProfileImage;

            var deletionResponse = await photoService.DeletePhotoAsync(imageToRemove.PublicId!);
            if (deletionResponse.Error != null) throw new ImageStoreException("Image was not deleted");

            existingUser.ProfileImage = null;
            context.Images.Remove(imageToRemove);
        }

        // Case 4 - update one photo to another
        else if (existingUser.ProfileImage != null && updatedUser.ProfileImage != null)
        {
            var oldImage = existingUser.ProfileImage;

            var deletionResponse = await photoService.DeletePhotoAsync(oldImage.PublicId!);
            if (deletionResponse.Error != null) throw new ImageStoreException("Image was not deleted");

            context.Images.Remove(oldImage);

            await context.Images.AddAsync(updatedUser.ProfileImage);
            existingUser.ProfileImage = updatedUser.ProfileImage;
        }
    }

    public async Task<MemberDto?> GetMemberByIdAsync(int id)
    {
        var user = await context.Users.FindAsync(id);
        if (user == null) throw new NotFoundException("User was not found");

        MemberDto? member = mapper.Map<MemberDto>(user);
        return member;
    }

    public async Task<MemberDto?> GetMemberByUniqueNameIdentifierAsync(string uniqueNameIdentifier)
    {
        var user = await context.Users.Include(a => a.ProfileImage).FirstOrDefaultAsync(u => u.UniqueNameIdentifier == uniqueNameIdentifier);
        if (user == null) throw new NotFoundException($"User with an unique name identifier of {uniqueNameIdentifier} was not found");

        MemberDto member = mapper.Map<MemberDto>(user);
        return member;
    }

    public async Task<User?> GetRawUserByEmailAsync(string email)
    {
        var user = await context.Users.FirstOrDefaultAsync(a => a.Email == email);
        if (user == null) throw new NotFoundException("User was not found");
        return user;
    }

    public async Task<List<MemberDto>> GetUsersByListOfIds(List<int> userIds)
    {
        var users = await context.Users.Include(a => a.ProfileImage)
            .Where(a => userIds.Contains(a.Id))
            .ProjectTo<MemberDto>(mapper.ConfigurationProvider)
            .ToListAsync();

        if (users == null) return new List<MemberDto>();
        return users;
    }

    public async Task<List<MemberDto>> SearchUsersByUniqueNameIdentifierAsync(string substring)
    {
        if (string.IsNullOrEmpty(substring)) return new List<MemberDto>();

        var users = await context.Users
            .Include(a => a.ProfileImage)
            .Where(a => a.UniqueNameIdentifier.Contains(substring))
            .ProjectTo<MemberDto>(mapper.ConfigurationProvider)
            .ToListAsync();

        return users;

    }

    public async Task<bool> CheckIfUserExistsByIdAsync(int userId)
    {
        return await context.Users.AnyAsync(a => a.Id == userId);
    }

    public async Task<bool> UpdateUserPassword(byte[] passwordHash, byte[] passwordSalt, int userId)
    {
        var user = await context.Users.FindAsync(userId);
        if (user == null) return false;

        user.PasswordHash = passwordHash;
        user.PaswordSalt = passwordSalt;

        context.Entry(user).Property(u => u.PasswordHash).IsModified = true;
        context.Entry(user).Property(u => u.PaswordSalt).IsModified = true;

        return await context.SaveChangesAsync() > 0;
    }

}
