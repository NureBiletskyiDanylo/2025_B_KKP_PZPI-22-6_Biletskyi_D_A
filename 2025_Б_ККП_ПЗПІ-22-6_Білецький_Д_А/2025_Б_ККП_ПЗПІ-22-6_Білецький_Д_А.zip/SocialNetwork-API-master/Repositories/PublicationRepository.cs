﻿using AutoMapper;
using Microsoft.EntityFrameworkCore;
using SocialNetworkAPI.Data;
using SocialNetworkAPI.Data.Entities;
using SocialNetworkAPI.DTOs;
using SocialNetworkAPI.Enums;
using SocialNetworkAPI.Exceptions;
using SocialNetworkAPI.Interfaces;
using System.Reflection.Metadata.Ecma335;
using System.Text;

namespace SocialNetworkAPI.Repositories;

public class PublicationRepository(DataContext context, IMapper mapper, IPhotoService photoService,
    ILoggingRepository loggingRepository) : IPublicationRepository
{
    public async Task<bool> CreatePublicationAsync(CreatePublicationDto publicationModel, int userId)
    {
        var user = await context.Users.FindAsync(userId);
        if (user == null) throw new ArgumentNullException(nameof(userId), "Author of a post was not found");

        Publication publication = mapper.Map<Publication>(publicationModel);
        publication.Author = user;
        publication.AuthorId = user.Id;


        List<Image> uploadedImages = new List<Image>();
        List<string> successfulUploads = new List<string>();


        using var transaction = context.Database.BeginTransaction();
        try
        {
            if (publicationModel.Images != null)
            {
                foreach (var image in publicationModel.Images)
                {
                    try
                    {
                        var response = await photoService.AddPhotoAsync(image);
                        if (response.Error != null) continue;

                        uploadedImages.Add(new Image
                        {
                            PublicId = response.PublicId,
                            ImageUrl = response.Url.AbsoluteUri
                        });

                        successfulUploads.Add(response.PublicId);
                    }
                    catch (Exception ex)
                    {
                        await loggingRepository.AddErrorLog(new ErrorLog
                        {
                            ErrorMessage = "An error during images deleting from post",
                            ErrorDetails = ex.Message

                        });
                    }
                }
            }

            if (uploadedImages.Count > 0)
            {
                publication.Images = uploadedImages;
            }

            await context.Publications.AddAsync(publication);
            bool result = await context.SaveChangesAsync() > 0;

            await transaction.CommitAsync();
            return result;
        }
        catch (Exception ex)
        {
            await transaction.RollbackAsync();

            if (successfulUploads.Count > 0)
            {
                await CleanupFailedUploads(successfulUploads);
            }
            throw new DbUpdateException("It was impossible to create a publication", ex);
        }
    }

    public async Task<bool> DeletePublicationAsync(int id)
    {
        var publication = await context.Publications.Include(a => a.Images).FirstOrDefaultAsync(a => a.Id == id);
        if (publication == null) throw new NotFoundException("Publication was not found");

        if(publication.Images != null)
        {
            foreach (var image in publication.Images)
            {
                await photoService.DeletePhotoAsync(image.PublicId!);
            }
        }

        context.Publications.Remove(publication);
        return await context.SaveChangesAsync() > 0;
    }

    public async Task<PublicationDto> GetPublicationByIdAsync(int id)
    {
        var publication = await context.Publications
            .Include(a => a.Author).ThenInclude(a => a.ProfileImage)
            .Include(a => a.Images)
            .Include(a => a.Likes)
            .Include(a => a.Comments)
            .FirstOrDefaultAsync(a => a.Id == id);
        if (publication == null) throw new NotFoundException("Publication was not found");
        var publicationModel = mapper.Map<PublicationDto>(publication);
        publicationModel.LikesAmount = publication.Likes.Count;
        return publicationModel;

    }

    public async Task<List<PublicationDto>> GetPublicationsFromUserAsync(string? uniqueName, int userId, int publicationsOwnerId = -1)
    {
        User? user;
        if (!string.IsNullOrEmpty(uniqueName))
        {
            user = await context.Users.FirstOrDefaultAsync(a => a.UniqueNameIdentifier == uniqueName);
        }
        else if (publicationsOwnerId > 0)
        {
            user = await context.Users.FindAsync(publicationsOwnerId);
        }
        else
        {
            throw new SystemException("Unfortunately, system has not received correct data to find user posts");
        }
        if (user == null) throw new NotFoundException("User was not found");
        var userPublications = await context.Publications
            .Include(a => a.Likes)
            .Include(a => a.Images)
            .Include(a => a.Author).ThenInclude(a => a.ProfileImage)
            .Include(a => a.Comments)
            .Where(a => a.AuthorId == user.Id).ToListAsync();
        if (user.CreatedPublications == null) return new List<PublicationDto>();
        else
        {
            var publications = mapper.Map<List<PublicationDto>>(userPublications);
            foreach(var publication in publications)
            {
                publication.IsLikedByCurrentUser = await IsLikedBy(userId, publication.Id);
            }
            return publications;
        }
    }

    public async Task<LikeDto> LikePost(int postId, int userId)
    {
        bool isLikedByUser = false;
        var postExists = await context.Publications.AnyAsync(a => a.Id == postId);
        if (!postExists) throw new NotFoundException("Post was not found");

        var userExists = await context.Users.AnyAsync(a => a.Id == userId);
        if (!userExists) throw new NotFoundException("Such user does not exist");

        var like = await context.Likes.FirstOrDefaultAsync(a => a.PublicationId == postId && a.LikedById == userId);
        if (like != null)
        {
            context.Likes.Remove(like);
        }
        else
        {
            await context.Likes.AddAsync(new Likes { LikedById = userId, PublicationId = postId });
            isLikedByUser = true;
        }
        bool success = await context.SaveChangesAsync() > 0;
        if (success)
        {
            int countOfLikes = await context.Publications
                .Include(a => a.Likes).Where(a => a.Id == postId)
                .Select(a => a.Likes.Count()).FirstOrDefaultAsync();
            LikeDto result = new LikeDto
            {
                AmountOfLikes = countOfLikes,
                IsLikedByCurrentUser = isLikedByUser
            };
            return result;
        }
        throw new DbUpdateException("Unfortunately the like was not registered");
    }

    public async Task<PublicationDto> UpdatePublication(UpdatePublicationDto model)
    {
        var publication = await context.Publications.Include(a => a.Images).Include(a => a.Author).FirstOrDefaultAsync(a => a.Id == model.Id);
        if (publication == null) throw new NotFoundException("Error, publication you want to update no longer exists");

        publication.Content = model.Content;
        if (publication.PublicationType == PublicationTypes.planned
            && (publication.RemindAt == null || publication.RemindAt != model.RemindAt)
            && model.RemindAt > DateTime.UtcNow)
        {
            publication.RemindAt = model.RemindAt;
        }

        publication.UpdatedAt = DateTime.UtcNow;
        bool success = await context.SaveChangesAsync() > 0;
        if (success) return mapper.Map<PublicationDto>(publication);
        throw new DbUpdateException("Publication unfortunately was not updated, try again later");
    }

    public async Task<bool> IsLikedBy(int userId, int publicationId)
    {
        return await context.Likes.AnyAsync(a => a.LikedById == userId && a.PublicationId == publicationId);
    }

    private async Task CleanupFailedUploads(List<string> publicIds)
    {
        foreach (var publicId in publicIds)
        {
            try
            {
                var result = await photoService.DeletePhotoAsync(publicId);
                if (result.Error != null) throw new ImageStoreException(result.Error.Message);
            }
            catch (Exception ex)
            {
                await loggingRepository.AddErrorLog(new ErrorLog
                {
                    ErrorMessage = "An error during images deleting from post",
                    ErrorDetails = ex.Message

                });
            }
        }
    }
}
