﻿using Microsoft.EntityFrameworkCore;
using SocialNetworkAPI.Data;
using SocialNetworkAPI.Data.Entities;
using SocialNetworkAPI.Interfaces;

namespace SocialNetworkAPI.Repositories;

public class LoggingRepository(DataContext context) : ILoggingRepository
{
    public async Task<bool> AddErrorLog(ErrorLog log)
    {
        await context.ErrorLogs.AddAsync(log);
        return await context.SaveChangesAsync() > 0;
    }

    public async Task<List<ErrorLog>> GetAllErrors()
    {
        List<ErrorLog> errors = await context.ErrorLogs.ToListAsync();
        return errors == null ? new List<ErrorLog>() : errors;
    }
}
