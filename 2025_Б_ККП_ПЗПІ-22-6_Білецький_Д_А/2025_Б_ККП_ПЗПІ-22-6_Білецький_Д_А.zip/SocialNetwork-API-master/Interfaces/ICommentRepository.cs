﻿namespace SocialNetworkAPI.Interfaces;

using SocialNetworkAPI.DTOs;

public interface ICommentRepository
{
    Task<CommentDto> CreateCommentAsync(CreateCommentDto model, int userId);
    Task<bool> DeleteCommentAsync(int id);
    Task<List<CommentDto>> GetCommentsByPostId(int postId);
}
