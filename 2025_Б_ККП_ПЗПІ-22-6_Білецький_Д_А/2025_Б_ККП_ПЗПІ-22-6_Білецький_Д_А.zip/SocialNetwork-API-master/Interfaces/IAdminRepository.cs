﻿namespace SocialNetworkAPI.Interfaces;

using SocialNetworkAPI.DTOs.AdminDTOs;

public interface IAdminRepository
{
    Task<bool> DeletePublication(CreateViolationDto violation);
    Task<bool> DeleteComment(CreateViolationDto violation);
    Task<bool> BlockUser(int userId);
    Task<bool> UnblockUser(int userId);
    Task<List<UserDto>> GetUsers();
    Task<List<ViolationDto>> GetViolationByUserIdAsync(int userId);
}
