﻿namespace SocialNetworkAPI.Interfaces;

public interface IEmailService
{
    Task SendEmailsAsync(List<string> emails, string subject, string body, bool isBodyHtml = false);
    Task SendEmailAsync(string email, string subject, string body, bool isBodyHtml = false);
}
