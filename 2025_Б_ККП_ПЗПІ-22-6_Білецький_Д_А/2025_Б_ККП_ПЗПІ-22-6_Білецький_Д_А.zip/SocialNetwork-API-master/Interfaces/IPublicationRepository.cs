﻿using SocialNetworkAPI.DTOs;

namespace SocialNetworkAPI.Interfaces;

public interface IPublicationRepository
{
    Task<bool> CreatePublicationAsync(CreatePublicationDto publication, int userId);
    Task<PublicationDto> GetPublicationByIdAsync(int id);
    Task<List<PublicationDto>> GetPublicationsFromUserAsync(string? uniqueName, int userId, int publicationsOwnerId = -1);
    Task<bool> DeletePublicationAsync(int id);
    Task<PublicationDto> UpdatePublication(UpdatePublicationDto model);
    Task<LikeDto> LikePost(int postId, int userId);
    Task<bool> IsLikedBy(int userId, int publicationId);
}
