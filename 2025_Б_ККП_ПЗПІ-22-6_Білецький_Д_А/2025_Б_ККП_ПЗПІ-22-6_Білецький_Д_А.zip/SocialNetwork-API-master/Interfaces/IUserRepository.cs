﻿using SocialNetworkAPI.Data.Entities;
using SocialNetworkAPI.DTOs;

namespace SocialNetworkAPI.Interfaces;

public interface IUserRepository
{
    Task<bool> CreateUserAccountAsync(User user);
    Task<bool> RemoveUserAccountAsync(User user);
    Task<bool> RemoveUserAccountByIdAsync(int userId);
    Task<MemberDto?> UpdateUserAccountAsync(User updatedUser);
    Task<MemberDto?> GetUserAccountByIdAsync(int userId);
    Task<MemberDto?> GetUserByEmailAsync(string email);
    Task<bool> CheckForUserExistenceByEmailAsync(string email);
    Task<bool> CheckIfUniqueNameIdentifierTaken(string nameIdentifier);
    Task<MemberDto?> GetMemberByUniqueNameIdentifierAsync(string uniqueNameIdentifier);
    Task<User?> GetRawUserByEmailAsync(string email);
    Task<List<MemberDto>> GetUsersByListOfIds(List<int> userIds);
    Task<List<MemberDto>> SearchUsersByUniqueNameIdentifierAsync(string substring);
    Task<bool> CheckIfUserExistsByIdAsync(int userId);
    Task<bool> UpdateUserPassword(byte[] passwordHash, byte[] passwordSalt, int userId);
}
