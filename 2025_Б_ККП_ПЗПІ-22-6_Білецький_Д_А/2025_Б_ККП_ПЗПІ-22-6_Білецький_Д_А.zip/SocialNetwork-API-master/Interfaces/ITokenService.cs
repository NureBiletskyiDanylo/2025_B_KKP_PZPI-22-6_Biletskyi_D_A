﻿using SocialNetworkAPI.Data.Entities;

namespace SocialNetworkAPI.Interfaces;

public interface ITokenService
{
    string CreateToken(User user);
}
