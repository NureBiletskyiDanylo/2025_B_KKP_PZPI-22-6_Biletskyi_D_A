﻿namespace SocialNetworkAPI.Interfaces;

using CloudinaryDotNet.Actions;

public interface IPhotoService
{
    Task<ImageUploadResult> AddProfilePhotoAsync(IFormFile image);
    Task<ImageUploadResult> AddPhotoAsync(IFormFile image);
    Task<DeletionResult> DeletePhotoAsync(string publicId);
}
