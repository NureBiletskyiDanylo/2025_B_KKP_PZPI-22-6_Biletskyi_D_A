﻿namespace SocialNetworkAPI.Interfaces;

public interface ISubscriptionService
{
    Task FollowAsync(int followerId, int followedId);
    Task UnfollowAsync(int followerId, int followedId);
    Task<List<int>> GetFollowersAsync(int userId);
    Task<List<int>> GetFollowingAsync(int userId);
    Task CreateUserNodeAsync(int userId);
    Task<bool> IsFollowing(int userId, int followedId);
}
