﻿using SocialNetworkAPI.Data.Entities;

namespace SocialNetworkAPI.Interfaces;

public interface ILoggingRepository
{
    Task<bool> AddErrorLog(ErrorLog log);
    Task<List<ErrorLog>> GetAllErrors();
}
