﻿namespace SocialNetworkAPI.Exceptions;

public class ImageStoreException : Exception
{
    public ImageStoreException() { }
    public ImageStoreException(string message) : base(message) { }
    public ImageStoreException(string message, Exception innerException)
        : base(message, innerException) { }
}
