﻿namespace SocialNetworkAPI.Services;

using Microsoft.Extensions.Caching.Memory;
using SocialNetworkAPI.Interfaces;
using System.Threading.Tasks;

public class PasswordResetService : IPasswordResetService
{
    private readonly IMemoryCache _cache;
    private readonly IServiceProvider _serviceProvider;
    private readonly int _codeExpiryMinutes = 10;

    public PasswordResetService(IServiceProvider serviceProvider, IMemoryCache cache)
    {
        _serviceProvider = serviceProvider;
        _cache = cache;
    }

    public async Task<string> GenerateAndStoreResetCode(string email)
    {
        using var scope = _serviceProvider.CreateScope();
        var userRepository = scope.ServiceProvider.GetRequiredService<IUserRepository>();
        var emailService = scope.ServiceProvider.GetRequiredService<IEmailService>();

        var user = await userRepository.GetRawUserByEmailAsync(email);
        if (user == null) return string.Empty;

        var code = GenerateRandomCode(10);

        _cache.Set(email, code, TimeSpan.FromMinutes(_codeExpiryMinutes));

        await emailService.SendEmailAsync(
            email,
            "Password Reset Code",
            $"Your password reset code is: {code}\nThis code will expire in {_codeExpiryMinutes} minutes.",
            false
        );

        return code;
    }

    public Task<bool> VerifyResetCode(string email, string code)
    {
        if (_cache.TryGetValue(email, out string? storedCode) && storedCode == code)
        {
            _cache.Remove(email);
            return Task.FromResult(true);
        }

        return Task.FromResult(false);
    }

    private static string GenerateRandomCode(int length)
    {
        const string chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
        var random = new Random();
        return new string(Enumerable.Repeat(chars, length)
            .Select(s => s[random.Next(s.Length)]).ToArray());
    }
}

