﻿namespace SocialNetworkAPI.Services;

using Microsoft.EntityFrameworkCore;
using SocialNetworkAPI.Data;
using SocialNetworkAPI.Data.Entities;
using SocialNetworkAPI.Interfaces;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

public class NotificationService : BackgroundService
{
    private readonly IServiceProvider _services;
    private readonly ILogger<NotificationService> _logger;
    private readonly TimeSpan _checkInterval = TimeSpan.FromSeconds(60);
    private const int BatchSize = 20;

    public NotificationService(IServiceProvider services, ILogger<NotificationService> logger)
    {
        _services = services;
        _logger = logger;
    }


    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        _logger.LogInformation("Notification Service started");

        while (!stoppingToken.IsCancellationRequested)
        {
            try
            {
                await ProcessPublicationsAsync(stoppingToken);
            }
            catch (Exception ex) when (ex is not OperationCanceledException)
            {
                _logger.LogError(ex, "Error in notification service main loop");
            }

            await Task.Delay(_checkInterval, stoppingToken);
        }
    }
    private async Task ProcessPublicationsAsync(CancellationToken stoppingToken)
    {
        using var scope = _services.CreateScope();
        var dbContext = scope.ServiceProvider.GetRequiredService<DataContext>();

        var now = DateTime.UtcNow;
        var skip = 0;
        List<Publication> publicationsBatch;

        do
        {
            publicationsBatch = await dbContext.Publications
                .Include(a => a.Author).ThenInclude(a => a.ProfileImage)
                .Include(a => a.Images)
                .Where(p => p.RemindAt != null && p.RemindAt <= now && !p.WasSent)
                .OrderBy(p => p.Id)
                .Skip(skip)
                .Take(BatchSize)
                .ToListAsync(stoppingToken);

            foreach (var publication in publicationsBatch)
            {
                await ProcessSinglePublicationAsync(publication, stoppingToken);
            }

            skip += BatchSize;
        } while (publicationsBatch.Count == BatchSize && !stoppingToken.IsCancellationRequested);
    }

    private async Task ProcessSinglePublicationAsync(Publication publication, CancellationToken stoppingToken)
    {
        try
        {
            using var publicationScope = _services.CreateScope();
            var dbContext = publicationScope.ServiceProvider.GetRequiredService<DataContext>();

            // Reload publication to ensure we have fresh data
            var currentPublication = await dbContext.Publications.Include(a => a.Author)
                .FirstOrDefaultAsync(p => p.Id == publication.Id, stoppingToken);

            if (currentPublication == null || currentPublication.WasSent) return;

            var followersIds = await GetFollowersIds(currentPublication.AuthorId);
            if (!followersIds.Any()) return;

            var emails = await dbContext.Users
                .Where(a => followersIds.Contains(a.Id))
                .Select(a => a.Email)
                .ToListAsync(stoppingToken);

            if (!emails.Any()) return;

            string body = await CreateBody(currentPublication, "https://localhost:4200");
            var emailService = publicationScope.ServiceProvider.GetRequiredService<IEmailService>();

            // Send emails in batches
            var batchSize = 10;
            for (int i = 0; i < emails.Count; i += batchSize)
            {
                var batch = emails.Skip(i).Take(batchSize).ToList();
                await emailService.SendEmailsAsync(batch, "New publication was published", body);

                if (i + batchSize < emails.Count)
                {
                    await Task.Delay(1000, stoppingToken); // Rate limiting
                }
            }

            currentPublication.WasSent = true;
            await dbContext.SaveChangesAsync(stoppingToken);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error processing publication {PublicationId}", publication.Id);
        }
    }

    private async Task<List<int>> GetFollowersIds(int authorId)
    {
        using var scope = _services.CreateScope();
        var subscriptionService = scope.ServiceProvider.GetRequiredService<ISubscriptionService>();
        List<int> ids = await subscriptionService.GetFollowersAsync(authorId);
        return ids ?? new List<int>();
    }


    private async Task<string> CreateBody(Publication publication, string appBaseUrl)
    {
        var author = publication.Author;
        var hasImages = publication.Images != null && publication.Images.Any();

        var body = $@"
<!DOCTYPE html>
<html>
<head>
    <!-- CSS styles from above -->
</head>
<body>
    <div class='container'>
        <div class='header'>
            <h2>New Publication from {author.Username}</h2>
        </div>
        
        <div class='content'>
            <p>Hello,</p>
            <p>{author.Username} has just published something new that you might find interesting:</p>
            
            <div class='publication-card'>
                <div class='author-info'>
                    <img src='{author.ProfileImage?.ImageUrl ?? "https://example.com/default-profile.png"}' 
                         alt='{author.Username}' class='profile-image'>
                    <div>
                        <div class='author-name'>{author.Username}</div>
                        <div class='timestamp'>Posted at: {publication.PostedAt.ToString("MMMM dd, yyyy h:mm tt")}</div>
                    </div>
                </div>
                
                <div class='publication-content'>
                    {publication.Content}
                </div>
                
                {(hasImages ? $@"
                <img src='{publication.Images!.First().ImageUrl}' 
                     alt='Publication image' class='publication-image'>
                " : "")}
                
                <div style='margin-top: 15px;'>
                    <a href='{appBaseUrl}/publications/{publication.Id}' class='button'>View Publication</a>
                </div>
            </div>
            
            <p style='margin-top: 25px;'>
                You're receiving this notification because you're following {author.Username}. 
            </p>
        </div>
        
        <div class='footer'>
            <a href='{appBaseUrl}'>Visit our website</a>
        </div>
    </div>
</body>
</html>";

        return body;
    }

}
