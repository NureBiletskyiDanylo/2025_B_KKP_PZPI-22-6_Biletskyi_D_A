﻿using SocialNetworkAPI.Data.Entities;
using SocialNetworkAPI.Exceptions;
using SocialNetworkAPI.Interfaces;

namespace SocialNetworkAPI.Middleware;

public class ExceptionHandlingMiddleware
{
    private readonly RequestDelegate _next;
    private readonly ILoggingRepository _repository;
    private readonly ILogger _logger;

    public ExceptionHandlingMiddleware(RequestDelegate next,
        ILoggingRepository repository, ILogger logger)
    {
        _next = next;
        _repository = repository;
        _logger = logger;
    }

    public async Task Invoke(HttpContext context)
    {
        try
        {
            await _next(context);
        }
        catch (Exception ex)
        {
            ErrorLog error = new ErrorLog
            {
                ErrorMessage = ex.Message,
                ErrorDetails = ex.InnerException?.Message
            };
            try
            {
                await _repository.AddErrorLog(error);
            }
            catch (Exception exc)
            {
                _logger.LogError(exc.Message, exc.InnerException, ex.Message, ex.InnerException);
            }
            context.Response.StatusCode = ex switch
            {
                ArgumentNullException => StatusCodes.Status400BadRequest,
                UnauthorizedAccessException => StatusCodes.Status401Unauthorized,
                NotFoundException => StatusCodes.Status404NotFound,
                ImageStoreException => StatusCodes.Status503ServiceUnavailable,
                _ => StatusCodes.Status500InternalServerError
            };

            context.Response.ContentType = "application/json";

            var response = new
            {
                error = ex.Message,
                detail = ex.InnerException?.Message, // REMOVE AT THE END BEFORE SHOWING (FOR DEBUGING)
                status = context.Response.StatusCode
            };

            await context.Response.WriteAsJsonAsync(response);
        }
    }
}