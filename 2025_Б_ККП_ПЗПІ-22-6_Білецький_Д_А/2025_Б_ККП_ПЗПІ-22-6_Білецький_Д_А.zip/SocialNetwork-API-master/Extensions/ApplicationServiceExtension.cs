﻿using MailKit.Net.Smtp;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Tokens;
using Neo4j.Driver;
using SocialNetworkAPI.Helpers;
using SocialNetworkAPI.Interfaces;
using SocialNetworkAPI.Repositories;
using SocialNetworkAPI.Services;
using System.Text;

namespace SocialNetworkAPI.Extensions;

public static class ApplicationServiceExtension
{
    public static IServiceCollection AddApplicationServices(this IServiceCollection services,
        IConfiguration configuration)
    {
        services.AddCors();
        services.AddScoped<IUserRepository, UserRepository>();
        services.AddScoped<ILoggingRepository, LoggingRepository>();
        services.AddScoped<IPublicationRepository, PublicationRepository>();
        services.AddScoped<ICommentRepository, CommentRepository>();
        services.AddScoped<IAdminRepository, AdminRepository>();

        services.AddScoped<IPhotoService, PhotoService>();
        services.Configure<CloudinarySettings>(configuration.GetSection("CloudinarySettings"));

        services.Configure<SmtpSettings>(configuration.GetSection("SmtpSettings"));

        services.AddScoped<IEmailService, EmailService>();

        services.AddSingleton<IPasswordResetService, PasswordResetService>();

        services.AddScoped<ITokenService, TokenService>();
        services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
            .AddJwtBearer(options =>
            {
                var tokenKey = configuration["TokenKey"] ?? throw new ArgumentException("Token key not found");
                options.TokenValidationParameters = new TokenValidationParameters
                {
                    ValidateIssuerSigningKey = true,
                    IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(tokenKey)),
                    ValidateIssuer = false,
                    ValidateAudience = false
                };
            });

        services.AddHostedService<NotificationService>();
        services.AddMemoryCache();
        services.AddAutoMapper(AppDomain.CurrentDomain.GetAssemblies());
        return services;
    }

}
