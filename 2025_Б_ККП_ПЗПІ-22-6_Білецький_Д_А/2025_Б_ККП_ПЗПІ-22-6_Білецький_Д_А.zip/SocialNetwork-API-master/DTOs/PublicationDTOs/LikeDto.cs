﻿namespace SocialNetworkAPI.DTOs;

public class LikeDto
{
    public int AmountOfLikes { get; set; }
    public bool IsLikedByCurrentUser { get; set; }
}
