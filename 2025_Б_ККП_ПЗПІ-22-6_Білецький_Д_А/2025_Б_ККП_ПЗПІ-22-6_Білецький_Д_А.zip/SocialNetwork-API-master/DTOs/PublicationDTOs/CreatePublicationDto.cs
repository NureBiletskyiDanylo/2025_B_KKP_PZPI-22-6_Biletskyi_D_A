﻿using SocialNetworkAPI.Enums;

namespace SocialNetworkAPI.DTOs
{
    public class CreatePublicationDto
    {
        public string? Content { get; set; }
        public PublicationTypes PublicationType { get; set; } = PublicationTypes.ordinary;
        public DateTime? RemindAt { get; set; }
        public List<IFormFile>? Images { get; set; }
    }
}
