﻿namespace SocialNetworkAPI.DTOs;

public class PublicationDto
{
    public int Id { get; set; }
    public string? Content { get; set; }
    public DateTime PostedAt { get; set; }
    public DateTime? UpdatedAt { get; set; }
    public DateTime? RemindAt { get; set; }
    public List<ImageDto> Images { get; set; }
    public MemberDto Author { get; set; }
    public int LikesAmount { get; set; }
    public bool IsLikedByCurrentUser { get; set; }
    public int CommentAmount { get; set; }
}
