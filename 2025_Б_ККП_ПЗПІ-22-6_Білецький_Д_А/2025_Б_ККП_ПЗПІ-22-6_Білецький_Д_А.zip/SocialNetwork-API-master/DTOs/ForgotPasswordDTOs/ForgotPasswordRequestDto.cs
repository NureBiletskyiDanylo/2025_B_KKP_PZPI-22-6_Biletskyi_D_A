﻿namespace SocialNetworkAPI.DTOs.ForgotPasswordDTOs;

using System.ComponentModel.DataAnnotations;

public class ForgotPasswordRequestDto
{
    [Required]
    [EmailAddress]
    public string Email { get; set; }
}
