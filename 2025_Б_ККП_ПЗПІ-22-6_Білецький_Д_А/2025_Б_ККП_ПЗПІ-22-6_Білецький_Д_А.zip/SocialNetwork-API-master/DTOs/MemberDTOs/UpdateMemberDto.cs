﻿namespace SocialNetworkAPI.DTOs;

public class UpdateMemberDto
{
    public int Id { get; set; }
    public string Username { get; set; } = string.Empty;
    public string UniqueNameIdentifier { get; set; } = string.Empty;
    public string JoinedAt { get; set; }
    public IFormFile? ProfileImage { get; set; }
}
