﻿namespace SocialNetworkAPI.DTOs;

public class ImageDto
{
    public int Id { get; set; }
    public string PublicId { get; set; } = string.Empty;
    public string ImageUrl { get; set; } = string.Empty;
}
