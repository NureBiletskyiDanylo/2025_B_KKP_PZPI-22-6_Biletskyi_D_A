﻿namespace SocialNetworkAPI.DTOs;

// For now, logindto and registerdto are equal, but in case I add new fields for user
// it may change the register form
public class RegisterDto
{
    public string Username { get; set; } = string.Empty;
    public string Email { get; set; } = string.Empty;
    public string Password { get; set; } = string.Empty;
    public IFormFile? Image { get; set; }
}
