﻿using Microsoft.AspNetCore.Mvc;

namespace SocialNetworkAPI.Controllers;

[Route("api/[controller]")]
[ApiController]
public class BaseApiController : ControllerBase
{
}
