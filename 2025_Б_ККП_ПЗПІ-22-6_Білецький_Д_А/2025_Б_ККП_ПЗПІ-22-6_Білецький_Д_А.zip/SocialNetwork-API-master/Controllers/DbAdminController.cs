﻿namespace SocialNetworkAPI.Controllers;

using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using SocialNetworkAPI.Data;
using SocialNetworkAPI.Interfaces;

public class DbAdminController(DataContext context, INeo4jDataAccess dataAccess) : BaseApiController
{
    [HttpGet("drop-all")]
    public async Task<ActionResult> DropAll()
    {
        try
        {
            await context.Database.EnsureDeletedAsync();
            await context.Database.EnsureCreatedAsync();
            await dataAccess.ClearDatabaseAsync();
            return Ok();
        }
        catch(Exception ex)
        {
            return BadRequest($"Error: {ex.Message}");
        }
    }
}
