﻿using AutoMapper;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using SocialNetworkAPI.Data.Entities;
using SocialNetworkAPI.DTOs;
using SocialNetworkAPI.Exceptions;
using SocialNetworkAPI.Extensions;
using SocialNetworkAPI.Interfaces;
using System.Security.Claims;

namespace SocialNetworkAPI.Controllers
{
    public class MemberController(IUserRepository userRepository, IMapper mapper,
        IPhotoService photoService) : BaseApiController
    {
        [Authorize]
        [HttpGet("by-uni")]
        public async Task<ActionResult> GetMemberByUni(string uniqueNameIdentifier)
        {
            var member = await userRepository.GetMemberByUniqueNameIdentifierAsync(uniqueNameIdentifier);
            if (member == null) return BadRequest("Something terribly went wrong while looking for a user");
            return Ok(member);
        }

        [Authorize]
        [HttpGet("my-profile")]
        public async Task<ActionResult> GetMyProfile()
        {
            int id = User.GetUserId(); 

            var member = await userRepository.GetUserAccountByIdAsync(id);
            if (member == null) return BadRequest("Error, the id is not valid");

            return Ok(member);
        }

        [Authorize]
        [HttpPut("edit")]
        public async Task<ActionResult> UpdateProfile(UpdateMemberDto model)
        {
            if (model == null) return BadRequest("Received data was corrupted. Editing profile is not possible now.");
            User user = mapper.Map<User>(model);
            if (model.ProfileImage != null)
            {
                var response = await photoService.AddPhotoAsync(model.ProfileImage);
                if (response.Error != null) throw new ImageStoreException("Image was not stored successfully");
                var image = new Image
                {
                    PublicId = response.PublicId,
                    ImageUrl = response.Url.AbsoluteUri
                };

                user.ProfileImage = image;
            }
            var updatedProfile = await userRepository.UpdateUserAccountAsync(user);
            if (updatedProfile == null) return BadRequest("During update some error has risen");
            return Ok(updatedProfile);
        }

        [Authorize]
        [HttpGet("other-user-profile")]
        public async Task<ActionResult> GetOtherUserProfile([FromQuery] string uniqueNameIdentifier)
        {
            if (string.IsNullOrEmpty(uniqueNameIdentifier)) return BadRequest("Data was corrupted, cannot find the user");
            MemberDto? member = await userRepository.GetMemberByUniqueNameIdentifierAsync(uniqueNameIdentifier);
            if (member == null) return BadRequest("Unfortunately, such user does not exist");
            return Ok(member);
        }

        [Authorize]
        [HttpGet("user-search")]
        public async Task<ActionResult> SearchForUserByUniqueNameIdentifier([FromQuery] string searchQuery)
        {
            var users = await userRepository.SearchUsersByUniqueNameIdentifierAsync(searchQuery);
            return Ok(users);
        }

    }
}
