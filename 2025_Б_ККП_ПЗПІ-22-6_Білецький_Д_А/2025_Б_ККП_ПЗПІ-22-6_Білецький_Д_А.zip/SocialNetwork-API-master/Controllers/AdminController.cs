﻿namespace SocialNetworkAPI.Controllers;

using CloudinaryDotNet.Actions;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.AspNetCore.Mvc;
using SocialNetworkAPI.DTOs.AdminDTOs;
using SocialNetworkAPI.Interfaces;

public class AdminController(IAdminRepository adminRepository) : BaseApiController
{
    [HttpPost("delete-comment")]
    public async Task<ActionResult> DeleteComment(CreateViolationDto violationDto)
    {
        bool result = await adminRepository.DeleteComment(violationDto);
        if (!result) return BadRequest("During execution something bad happened");

        return Ok();
    }

    [HttpPost("delete-publication")]
    public async Task<ActionResult> DeletePublication(CreateViolationDto violationDto)
    {
        bool result = await adminRepository.DeletePublication(violationDto);
        if (!result) return BadRequest("During execution something bad happened");

        return Ok();
    }

    [HttpPost("block-user")]
    public async Task<ActionResult> BlockUser([FromBody]int userId)
    {
        bool result = await adminRepository.BlockUser(userId);
        if (!result) return BadRequest("User was not blocked");

        return Ok();
    }

    [HttpPost("unblock-user")]
    public async Task<ActionResult> UnblockUser([FromBody]int userId)
    {
        bool result = await adminRepository.UnblockUser(userId);
        if (!result) return BadRequest("User was not unblocked");

        return Ok();
    }

    [HttpGet("get-users")]
    public async Task<ActionResult> GetUsers()
    {
        var users = await adminRepository.GetUsers();
        return Ok(users);
    }

    [HttpGet("violations/{id:int}")]
    public async Task<ActionResult> GetViolations(int id)
    {
        var violations = await adminRepository.GetViolationByUserIdAsync(id);
        return Ok(violations);
    }
}
