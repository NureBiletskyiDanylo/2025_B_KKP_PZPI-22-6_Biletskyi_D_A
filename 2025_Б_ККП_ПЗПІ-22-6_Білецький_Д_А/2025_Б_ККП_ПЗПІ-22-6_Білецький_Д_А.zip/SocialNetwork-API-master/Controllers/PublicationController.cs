﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using SocialNetworkAPI.Data.Entities;
using SocialNetworkAPI.DTOs;
using SocialNetworkAPI.Extensions;
using SocialNetworkAPI.Interfaces;

namespace SocialNetworkAPI.Controllers;
public class PublicationController(IPublicationRepository publicationRepository) : BaseApiController
{
    [Authorize]
    [HttpPost("create-publication")]
    public async Task<ActionResult> CreatePublication(CreatePublicationDto model)
    {
        int userId = User.GetUserId();

        bool result = await publicationRepository.CreatePublicationAsync(model, userId);
        if (!result) return BadRequest("Publication was not created");
        return Ok();
    }

    [Authorize]
    [HttpPut("update-publication")]
    public async Task<ActionResult> UpdatePublication(UpdatePublicationDto model)
    {
        var userId = User.GetUserId();
        if (model == null) return BadRequest("Model unfortunately was null");

        PublicationDto? updatedModel = await publicationRepository.UpdatePublication(model);
        if (updatedModel == null) return BadRequest("Unfortunately update was not successful");
        updatedModel.IsLikedByCurrentUser = await publicationRepository.IsLikedBy(userId, updatedModel.Id);
        return Ok(updatedModel);
    }

    [Authorize]
    [HttpGet("publication-of-{uniqueNameIdentifier}")]
    public async Task<ActionResult> GetPublicationsOfAuthor(string uniqueNameIdentifier)
    {
        var userId = User.GetUserId();
        if (string.IsNullOrEmpty(uniqueNameIdentifier))
        {
            return BadRequest("You have not provided a name identifier for a person whose posts you are looking for");
        }

        var publications = await publicationRepository.GetPublicationsFromUserAsync(uniqueNameIdentifier, userId);
        return Ok(publications);
    }

    [Authorize]
    [HttpGet("{id:int}")]
    public async Task<ActionResult> GetPublicationById(int id)
    {
        int userId = User.GetUserId();
        PublicationDto publication = await publicationRepository.GetPublicationByIdAsync(id);
        if (publication == null) return NotFound("Publication was not found");
        publication.IsLikedByCurrentUser = await publicationRepository.IsLikedBy(userId, id);
        return Ok(publication);
    }

    [Authorize]
    [HttpDelete("{id:int}")]
    public async Task<ActionResult> DeletePublication(int id)
    {
        var result = await publicationRepository.DeletePublicationAsync(id);
        if (!result) return BadRequest("Unfortunately deletion was not successful");
        return Ok();
    }

    [Authorize]
    [HttpGet("like/{id:int}")]
    public async Task<ActionResult> LikePost(int id)
    {
        var userId = User.GetUserId();

        var likeProcessed = await publicationRepository.LikePost(id, userId);
        if (likeProcessed == null) return BadRequest("Something went wrong during like processing");
        return Ok(likeProcessed);
    }
}
