﻿namespace SocialNetworkAPI.Controllers;

using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using SocialNetworkAPI.Extensions;
using SocialNetworkAPI.Interfaces;
using System.Runtime.CompilerServices;

public class SubscriptionController(ISubscriptionService subscriptionService, IUserRepository userRepository) : BaseApiController
{
    [Authorize]
    [HttpPost("subscribe")]
    public async Task<ActionResult> Subscribe([FromBody] string uniqueNameIdentifier)
    {
        var currentUserId = User.GetUserId();
        var currentUser = await userRepository.GetUserAccountByIdAsync(currentUserId);
        if (currentUser == null) return BadRequest("Not identified user cannot subscribe");

        var subscribeOn = await userRepository.GetMemberByUniqueNameIdentifierAsync(uniqueNameIdentifier);
        if (subscribeOn == null) return BadRequest("You cannot subscribe on non-existent user");


        try
        {
            await subscriptionService.FollowAsync(currentUserId, subscribeOn.Id);
            return Ok();
        }
        catch (Exception ex)
        {
            return BadRequest($"During subscription something went wrong: {ex.Message}");
        }

    }

    [HttpGet("subscriptions-count")]
    public async Task<ActionResult> GetSubscriptionsCount([FromQuery] string uniqueNameIdentifier)
    {
        var user = await userRepository.GetMemberByUniqueNameIdentifierAsync(uniqueNameIdentifier);
        if (user == null) return BadRequest("Such user does not exist");

        try
        {
            var result = await subscriptionService.GetFollowingAsync(user.Id);
            return Ok(result.Count);
        }
        catch (Exception ex)
        {
            return BadRequest($"During getting process of subscriptions something went wrong: {ex.Message}");
        }
    }

    [HttpGet("followers-count")]
    public async Task<ActionResult> GetFollowersCount([FromQuery] string uniqueNameIdentifier)
    {
        var user = await userRepository.GetMemberByUniqueNameIdentifierAsync(uniqueNameIdentifier);
        if (user == null) return BadRequest("Such user does not exist");

        try
        {
            var result = await subscriptionService.GetFollowersAsync(user.Id);
            return Ok(result.Count);
        }
        catch (Exception ex)
        {
            return BadRequest($"During getting process of subscriptions something went wrong: {ex.Message}");
        }
    }

    [Authorize]
    [HttpPost("unsubscribe")]
    public async Task<ActionResult> Unsubscribe([FromBody] string uniqueNameIdentifier)
    {
        var currentUserId = User.GetUserId();
        var currentUser = await userRepository.GetUserAccountByIdAsync(currentUserId);
        if (currentUser == null) return BadRequest("Not identified user cannot unsubscribe");

        var unsubscribeFrom = await userRepository.GetMemberByUniqueNameIdentifierAsync(uniqueNameIdentifier);
        if (unsubscribeFrom == null) return BadRequest("You cannot unsubscribe from account that no longer exists");

        try
        {
            await subscriptionService.UnfollowAsync(currentUserId, unsubscribeFrom.Id);
            return Ok();
        }
        catch (Exception ex)
        {
            return BadRequest($"During unsubscribing something went wrong: {ex.Message}");
        }
    }

    [Authorize]
    [HttpGet("subscriptions")]
    public async Task<ActionResult> GetSubscriptions([FromQuery] string uniqueNameIdentifier)
    {
        var user = await userRepository.GetMemberByUniqueNameIdentifierAsync(uniqueNameIdentifier);
        if (user == null) return BadRequest("Such user does not exist");

        try
        {
            var result = await subscriptionService.GetFollowingAsync(user.Id);

            var subscriptions = await userRepository.GetUsersByListOfIds(result);

            return Ok(subscriptions);
        }
        catch (Exception ex)
        {
            return BadRequest($"During getting subscriptions something went wrong: {ex.Message}");
        }
    }

    [Authorize]
    [HttpGet("followers")]
    public async Task<ActionResult> GetFollowers([FromQuery] string uniqueNameIdentifier)
    {
        var user = await userRepository.GetMemberByUniqueNameIdentifierAsync(uniqueNameIdentifier);
        if (user == null) return BadRequest("Such user does not exist");

        try
        {
            var result = await subscriptionService.GetFollowersAsync(user.Id);

            var followers = await userRepository.GetUsersByListOfIds(result);
            return Ok(followers);
        }
        catch (Exception ex)
        {
            return BadRequest($"During getting followers omething went wrong: {ex.Message}");
        }
    }

    [Authorize]
    [HttpGet("is-following")]
    public async Task<ActionResult> IsFollowing([FromQuery] string uniqueNameIdentifier)
    {
        var currentUserId = User.GetUserId();
        var currentUser = await userRepository.GetUserAccountByIdAsync(currentUserId);
        if (currentUser == null) return BadRequest("Unauthorized user cannot get information if user is following someone");

        if (string.IsNullOrEmpty(uniqueNameIdentifier)) return BadRequest("Unfortunately data was corrupted");
        var otherUser = await userRepository.GetMemberByUniqueNameIdentifierAsync(uniqueNameIdentifier);
        if (otherUser == null) return BadRequest("User you want to check if you are subscribed on does not exist");

        try
        {
            bool isFollowing = await subscriptionService.IsFollowing(currentUserId, otherUser.Id);
            return Ok(isFollowing);
        }
        catch (Exception ex)
        {
            return BadRequest($"During checking if user is followed on another user, an error happened: {ex.Message}");
        }
    }
}
