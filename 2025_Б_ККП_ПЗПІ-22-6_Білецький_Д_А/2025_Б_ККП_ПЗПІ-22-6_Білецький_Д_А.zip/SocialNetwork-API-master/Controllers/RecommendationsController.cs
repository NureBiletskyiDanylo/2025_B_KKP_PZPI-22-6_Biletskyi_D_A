﻿namespace SocialNetworkAPI.Controllers;

using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using SocialNetworkAPI.Data.Entities;
using SocialNetworkAPI.DTOs;
using SocialNetworkAPI.Extensions;
using SocialNetworkAPI.Interfaces;

public class RecommendationsController(IUserRepository userRepository,
    IPublicationRepository publicationRepository, ISubscriptionService subscriptionService) : BaseApiController
{

    //Test version of recommendations
    [HttpGet]
    [Authorize]
    public async Task<ActionResult> GetRecommendations()
    {
        int userId = User.GetUserId();

        if (!await userRepository.CheckIfUserExistsByIdAsync(userId))
            return BadRequest("User does not exist. Please relogin again");

        List<int> subscriptions;
        try
        {
            subscriptions = await subscriptionService.GetFollowingAsync(userId);
        }
        catch(Exception ex)
        {
            return BadRequest($"Error happened: {ex.Message}");
        }


        List<PublicationDto> publications = new List<PublicationDto>();
        foreach (var subscription in subscriptions)
        {
            var userPublications = await publicationRepository.GetPublicationsFromUserAsync(null, userId, subscription);
            publications.AddRange(userPublications);
        }

        publications = publications.OrderByDescending(a => a.PostedAt).ThenByDescending(a => a.LikesAmount).ToList();
        return Ok(publications);
    }
}
