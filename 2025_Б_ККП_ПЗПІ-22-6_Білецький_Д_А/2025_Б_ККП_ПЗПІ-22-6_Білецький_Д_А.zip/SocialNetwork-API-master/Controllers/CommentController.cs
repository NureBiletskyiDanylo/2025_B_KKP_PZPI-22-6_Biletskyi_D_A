﻿namespace SocialNetworkAPI.Controllers;

using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using SocialNetworkAPI.DTOs;
using SocialNetworkAPI.Extensions;
using SocialNetworkAPI.Interfaces;

public class CommentController(ICommentRepository commentRepository) : BaseApiController
{
    [Authorize]
    [HttpGet("{publicationId:int}")]
    public async Task<ActionResult> GetComments(int publicationId)
    {
        var comments = await commentRepository.GetCommentsByPostId(publicationId);
        return Ok(comments);
    }

    [Authorize]
    [HttpPost]
    public async Task<ActionResult> CreateComment(CreateCommentDto model)
    {
        if (model == null) return BadRequest("Unfortunately comment data was not received");

        var userId = User.GetUserId();
        var comment = await commentRepository.CreateCommentAsync(model, userId);
        if (comment != null) return Ok(comment);
        return BadRequest("Unfortunately comment was not created. Try again later!");
    }

    [Authorize]
    [HttpDelete("{id:int}")]
    public async Task<ActionResult> DeleteComment(int id)
    {
        bool result = await commentRepository.DeleteCommentAsync(id);
        if (result) return Ok();
        return BadRequest("Unfortunately comment was not deleted. Try again later!");
    }
}
