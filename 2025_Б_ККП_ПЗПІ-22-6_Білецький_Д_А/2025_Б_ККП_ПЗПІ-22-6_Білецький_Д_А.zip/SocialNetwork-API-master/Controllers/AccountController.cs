﻿using System.Text;
using Microsoft.AspNetCore.Mvc;
using SocialNetworkAPI.Data.Entities;
using SocialNetworkAPI.DTOs;
using SocialNetworkAPI.Interfaces;
using System.Security.Cryptography;
using SocialNetworkAPI.Exceptions;
using System.Reflection.Metadata.Ecma335;
using Neo4j.Driver;
using Microsoft.AspNetCore.Identity.Data;
using SocialNetworkAPI.DTOs.ForgotPasswordDTOs;

namespace SocialNetworkAPI.Controllers
{
    public class AccountController(IUserRepository userRepository, ITokenService tokenService,
        IPhotoService photoService, ISubscriptionService subscriptionService, IPasswordResetService passwordResetService) : BaseApiController
    {
        const int RANDOM_NAME_IDENTIFIER_KEY_VALUE_LENGTH = 7;
        [HttpPost("login")]
        public async Task<ActionResult> Login(LoginDto loginModel)
        {
            if (loginModel == null) return BadRequest("Internal error. Data was not received");
            User? user = await userRepository.GetRawUserByEmailAsync(loginModel.Email);
            if (user == null) return BadRequest("User with specified email does not exist");

            using var hmac = new HMACSHA512(user.PaswordSalt);

            var computedHash = hmac.ComputeHash(Encoding.UTF8.GetBytes(loginModel.Password));

            for (int i = 0; i < computedHash.Length; i++)
            {
                if (computedHash[i] != user.PasswordHash[i]) return Unauthorized("Invalid credentials");
            }

            AccountClaimsDto account = new AccountClaimsDto
            {
                UniqueNameIdentifier = user.UniqueNameIdentifier,
                Username = user.Username,
                Token = tokenService.CreateToken(user),
                Role = user.Role.ToString(),
                Blocked = user.Blocked
            };

            return Ok(account);
        }

        [HttpPost("register")]
        public async Task<ActionResult> Register(RegisterDto registerModel)
        {
            if (registerModel == null) return BadRequest("Internal error. Data was not received");
            bool exists = await userRepository.CheckForUserExistenceByEmailAsync(registerModel.Email);

            if (exists) return BadRequest("The user with this email already exists");

            using var hmac = new HMACSHA512();

            string uniqueNameIdentifier = await BuildUniqueNameIdentifier(registerModel.Username);
            var user = new User
            {
                Username = registerModel.Username,
                Email = registerModel.Email,
                UniqueNameIdentifier = uniqueNameIdentifier,
                PasswordHash = hmac.ComputeHash(Encoding.UTF8.GetBytes(registerModel.Password)),
                PaswordSalt = hmac.Key,
                Role = Enums.Roles.User
            };

            if (registerModel.Image != null)
            {
                var newImage = await AddImageAsync(registerModel.Image);
                user.ProfileImage = newImage;
            }

            bool created = await userRepository.CreateUserAccountAsync(user);
            if (!created) return BadRequest("Internal error. User accoun was not created. Try again later");

            try
            {
                await subscriptionService.CreateUserNodeAsync(user.Id);
            }
            catch (Exception ex)
            {
                throw new Neo4jException($"User node was not created: {ex.Message}");
            }

            AccountClaimsDto account = new AccountClaimsDto
            {
                UniqueNameIdentifier = user.UniqueNameIdentifier,
                Username = user.Username,
                Role = user.Role.ToString(),
                Token = tokenService.CreateToken(user),
                Blocked = false
            };
            return Ok(account);
        }

        [HttpPost("forgot-password")]
        public async Task<ActionResult> ForgotPassword(ForgotPasswordRequest model)
        {
            if (model == null) return BadRequest("Unfortunately, received request was not processed");

            await passwordResetService.GenerateAndStoreResetCode(model.Email);

            return Ok();
        }

        [HttpPost("verify-reset-code")]
        public async Task<ActionResult> VerifyResetCode(VerifyCodeDto model)
        {
            if (model == null) return BadRequest("Unfortunately, received request was not processed");

            var isValid = await passwordResetService.VerifyResetCode(model.Email, model.Code);

            if (!isValid) return BadRequest("Invalid or expired reset code");

            return Ok();
        }

        [HttpPost("reset-password")]
        public async Task<ActionResult> ResetPassword(ResetPasswordDto model)
        {
            if (model == null) return BadRequest("Unfortunately, received request was not processed");

            var user = await userRepository.GetRawUserByEmailAsync(model.Email);
            if (user == null)
            {
                return BadRequest("Something went wrong. User was not found");
            }

            using var hmac = new HMACSHA512();
            var hash = hmac.ComputeHash(Encoding.UTF8.GetBytes(model.NewPassword));
            var salt = hmac.Key;

            bool result = await userRepository.UpdateUserPassword(hash, salt, user.Id);
            if (result) return Ok();
            return BadRequest("Password was not updated");
        }

        private async Task<string> BuildUniqueNameIdentifier(string username)
        {
            StringBuilder sb = new StringBuilder(username);
            bool nameIdentifierExists = await userRepository.CheckIfUniqueNameIdentifierTaken(username);
            while (nameIdentifierExists)
            {
                sb.Append('-');
                sb.Append(GenerateRandomString());
                nameIdentifierExists = await userRepository.CheckIfUniqueNameIdentifierTaken(sb.ToString());
            }

            return sb.ToString();
        }

        private static string GenerateRandomString()
        {
            StringBuilder sb = new StringBuilder();
            Random rand = new Random();
            int randCharValue;
            int randCaseValue;
            char letter;
            for (int i = 0; i < RANDOM_NAME_IDENTIFIER_KEY_VALUE_LENGTH; i++)
            {
                randCharValue = rand.Next(0, 26);
                randCaseValue = rand.Next(0, 1);

                letter = Convert.ToChar(randCharValue + 65);
                letter = randCaseValue == 0 ? char.ToLower(letter) : letter;

                sb.Append(letter); 
            }

            return sb.ToString();
        }

        private async Task<Image> AddImageAsync(IFormFile image)
        {
            var response = await photoService.AddProfilePhotoAsync(image);
            if (response.Error != null)
                throw new ImageStoreException(response.Error.Message);

            Image newImage = new Image
            {
                ImageUrl = response.Url.AbsoluteUri,
                PublicId = response.PublicId
            };
            return newImage;
        }
    }
}
